vlib work
vlog vending_ds.v
vlog vending_tb.v
vsim work.tb
add wave -r tb/u1/*
run -all